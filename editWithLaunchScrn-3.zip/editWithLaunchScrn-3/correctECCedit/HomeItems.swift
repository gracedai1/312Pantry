//
//  URLlinks.swift
//  correctECCedit
//
//  Created by admin on 7/27/21.
//

import Foundation

class todaysCells {
    var name: String!
    var website: String!
    var address: String!
    
    init(name: String, website: String, address: String)
        {self.name = name
        self.website = website
        self.address = address
    }
}
